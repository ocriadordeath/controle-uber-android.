package br.com.controleuber

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF151F30)
private val Green = Color(0xFF22C55E)
private val Muted = Color(0xFF9AA8BC)
private val currency = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

data class Entry(val id: String, val type: String, val title: String, val amount: Double, val detail: String, val date: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UberApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UberApp(activity: ComponentActivity) {
    val prefs = activity.getSharedPreferences("controle_uber", 0)
    val entries = remember {
        mutableStateListOf<Entry>().apply {
            val raw = prefs.getString("entries", "[]") ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(Entry(o.getString("id"), o.getString("type"), o.getString("title"),
                    o.getDouble("amount"), o.optString("detail"), o.getLong("date")))
            }
        }
    }
    fun persist() {
        val arr = JSONArray()
        entries.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("type", e.type).put("title", e.title)
                .put("amount", e.amount).put("detail", e.detail).put("date", e.date))
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }
    var tab by remember { mutableStateOf("Início") }
    var showForm by remember { mutableStateOf(false) }
    var formType by remember { mutableStateOf("Ganho") }

    val income = entries.filter { it.type == "Ganho" }.sumOf { it.amount }
    val expenses = entries.filter { it.type != "Ganho" }.sumOf { it.amount }
    val fuel = entries.filter { it.type == "Combustível" }.sumOf { it.amount }
    val profit = income - expenses

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            floatingActionButton = {
                FloatingActionButton(onClick = { formType = "Ganho"; showForm = true }, containerColor = Green, contentColor = Color.Black) {
                    Icon(Icons.Default.Add, contentDescription = "Adicionar")
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Início", "Lançamentos").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(if (item == "Início") Icons.Default.Home else Icons.Default.ReceiptLong, null) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Bg)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Text("CONTROLE UBER", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(if (tab == "Início") "Seu resumo" else "Seus lançamentos", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                if (tab == "Início") {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp)) {
                            Text("LUCRO LÍQUIDO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(7.dp))
                            Text(currency.format(profit), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = if (profit >= 0) Green else Color(0xFFF87171))
                            Text("Ganhos menos despesas cadastradas", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("Ganhos", income, Green, Modifier.weight(1f))
                        SummaryCard("Despesas", expenses, Color(0xFFF87171), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("Combustível", fuel, Color(0xFFFBBF24), Modifier.weight(1f))
                        SummaryCard("Registros", entries.size.toDouble(), Color.White, Modifier.weight(1f), numeric = true)
                    }
                    Spacer(Modifier.height(22.dp))
                    Text("Adicionar lançamento", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickButton("Ganho", Green) { formType = "Ganho"; showForm = true }
                        QuickButton("Combustível", Color(0xFFFBBF24)) { formType = "Combustível"; showForm = true }
                        QuickButton("Despesa", Color(0xFFF87171)) { formType = "Despesa"; showForm = true }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("Últimos registros", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    EntryList(entries.sortedByDescending { it.date }.take(5), onDelete = { id -> entries.removeAll { it.id == id }; persist() })
                } else {
                    EntryList(entries.sortedByDescending { it.date }, onDelete = { id -> entries.removeAll { it.id == id }; persist() })
                }
            }
        }
        if (showForm) {
            EntryDialog(initialType = formType, onDismiss = { showForm = false }) { type, title, amount, detail ->
                entries.add(Entry(UUID.randomUUID().toString(), type, title, amount, detail, System.currentTimeMillis()))
                persist()
                showForm = false
            }
        }
    }
}

@Composable
fun SummaryCard(label: String, value: Double, tint: Color, modifier: Modifier = Modifier, numeric: Boolean = false) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(label, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(7.dp))
            Text(if (numeric) value.toInt().toString() else currency.format(value), color = tint, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
fun QuickButton(label: String, tint: Color, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = tint),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp), shape = RoundedCornerShape(12.dp)) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun EntryList(items: List<Entry>, onDelete: (String) -> Unit) {
    if (items.isEmpty()) {
        Text("Nenhum lançamento ainda. Toque no botão + para começar.", color = Muted, modifier = Modifier.padding(vertical = 20.dp))
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(items, key = { it.id }) { e ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.title, fontWeight = FontWeight.SemiBold)
                            Text("${e.type}${if (e.detail.isNotBlank()) " • ${e.detail}" else ""}", color = Muted, fontSize = 12.sp)
                        }
                        Text((if (e.type == "Ganho") "+" else "−") + currency.format(e.amount), color = if (e.type == "Ganho") Green else Color(0xFFF87171), fontWeight = FontWeight.Bold)
                        TextButton(onClick = { onDelete(e.id) }) { Text("Excluir", color = Muted, fontSize = 11.sp) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryDialog(initialType: String, onDismiss: () -> Unit, onSave: (String, String, Double, String) -> Unit) {
    var type by remember { mutableStateOf(initialType) }
    var title by remember { mutableStateOf(if (initialType == "Ganho") "Viagens Uber" else initialType) }
    var amount by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    val types = listOf("Ganho", "Combustível", "Despesa")
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Novo lançamento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Tipo", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    types.forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t, fontSize = 11.sp) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Descrição") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.replace(",", ".").filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Valor em R$") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(value = detail, onValueChange = { detail = it }, label = { Text("Observação (opcional)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = amount.toDoubleOrNull()
                if (title.isNotBlank() && v != null && v > 0) onSave(type, title.trim(), v, detail.trim())
            }) { Text("Salvar", color = Green) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
